import java.util.ArrayList;
import java.util.Scanner;

public class XuLy {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		CongTy congTy = new CongTy();
		congTy.nhap();
		doMenu(congTy);
	}
	private static void inMenu() {
		System.out.println("Vui lòng chọn thực hiện:");
		System.out.println("1. Thêm nhân viên");
		System.out.println("2. Xuất danh sách nhân viên");
		System.out.println("3. Liệt kê nhân viên lương cao nhất");
		System.out.println("0. Thoát");
	}

	private static void doMenu(CongTy congTy) {
		boolean flag = true;
		Scanner scan = new Scanner(System.in);
		do {
			
			inMenu();
			System.out.print("Mời chọn:");
			int chon = Integer.parseInt(scan.nextLine());
			switch (chon) {
			case 1:
				NhanVien nv = new NhanVien();
				nv.nhapNhanVien(scan);
				congTy.themNhanVien(nv);
				break;
			case 2:
				//Tính lương để xuất thông tin đầy đủ.
				congTy.tinhLuong();
				congTy.xuatTheoFormat(congTy.getListNVCongTy().getListNV());
				break;
			case 3:
				//Tính lương để xuất thông tin đầy đủ.
				congTy.tinhLuong();
				ArrayList<NhanVien> listNVLuongCaoNhat = congTy.TimNVCoLuongCaoNhat();
				congTy.xuatTheoFormat(listNVLuongCaoNhat);
				break;
			case 0:
				flag = false;
				break;
			}
		} while (flag);
	}

}
