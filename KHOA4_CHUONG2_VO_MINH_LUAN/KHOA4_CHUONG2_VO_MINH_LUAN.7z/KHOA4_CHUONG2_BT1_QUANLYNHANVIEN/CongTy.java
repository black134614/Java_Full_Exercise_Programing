import java.util.ArrayList;
/*
 * Mục đích: Tạo ra để quản lý nghiệp vụ của công ty
 * Người tạo: Minh Luân
 * Ngày tạo: 27/12/2021
 * Version: 1.0
 * */
public class CongTy {
	// 1. Thuộc tính
	private DanhSachNhanVien listNVCongTy;
	// 2. Get, set methods
	/**
	 * @return the listNVCongTy
	 */
	public DanhSachNhanVien getListNVCongTy() {
		return listNVCongTy;
	}
	/**
	 * @param listNVCongTy the listNVCongTy to set
	 */
	public void setListNVCongTy(DanhSachNhanVien listNV) {
		this.listNVCongTy = listNV;
	}
	// 3. Constructors method
	public CongTy() {
		thietLapDefault();
	}
	// Hàm này dùng để khởi động các list và các giá trị mặc định cho lớp công ty
	private void thietLapDefault() {
		this.listNVCongTy = new DanhSachNhanVien() ;
	}
	// 4. Input, output methods
	public void nhap() {
		NhanVien nv = new NhanVien(2000, "Võ Minh Luân", "06/06/1997", "Bình Chuẩn - Thuận An - Bình Dương", 3.3f, 5000000);
		this.listNVCongTy.themNhanVien(nv);
		
		nv = new NhanVien(2001, "Nguyễn Hải My", "03/12/2001", "Thuận Giao - Thuận An - Bình Dương", 3.3f, 5000000);
		this.listNVCongTy.themNhanVien(nv);
		
		nv = new NhanVien(2002, "Văn Trọng", "01/05/1997", "Tây Ninh", 2.7f, 4500000);
		this.listNVCongTy.themNhanVien(nv);
		
		nv = new NhanVien(2003, "Lê Văn Thư", "19/05/1997", "Tây Ninh", 3, 5000000);
		this.listNVCongTy.themNhanVien(nv);
		
		nv = new NhanVien(2004, "Võ Hải Yến", "08/09/2021", "Tây Ninh", 3.1f, 5000000);
		this.listNVCongTy.themNhanVien(nv);
	}
	public void xuat() {
		this.listNVCongTy.xuat();
	}
	// 5. Business methods
	//thêm nhân viên
	public void themNhanVien(NhanVien nv) {
		this.listNVCongTy.themNhanVien(nv);
	}
	//Tính Lương
	public void tinhLuong() {
		this.listNVCongTy.tinhLuong();
	}
	//tìm nhân viên có lương cao nhất
	public ArrayList<NhanVien> TimNVCoLuongCaoNhat() {
		return this.listNVCongTy.timNVCoLuongCaoNhat();
	}
	//format xuất thông tin
	private void xuatLine() {
		System.out.println(
				"===================================================================================================================");
	}

	private String formatCell(String paddLeft, String title, String paddRight) {
		return String.format(paddLeft, " ") + title + String.format(paddRight, " ");
	}

	private void xuatRowHeader() {
		String paddString0 = "%1s";
		String paddString1 = "%3s";
		String paddString2 = "%4s";
		String paddString3 = "%5s";
		String paddString4 = "%2s";
		String paddString5 = "%10s";
		String paddString6 = "%23s";

		xuatLine();
		String text;
		text = "||" + formatCell(paddString1, "STT", paddString1) + "|";
		text += formatCell(paddString2, "Mã NV", paddString2)+ "|";
		text += formatCell(paddString3, "Tên NV", paddString2)+ "|";
		text += formatCell(paddString1, "Ngày Sinh", paddString1)+ "|";
		text += formatCell(paddString5, "Địa Chỉ", paddString6)+ "|";
		text += formatCell(paddString0, "Hệ số lương", paddString0)+ "|";
		text += formatCell(paddString0, "Lương cơ bản", paddString4)+ "|";
		text += formatCell(paddString3, "Lương", paddString3) + "||";
		System.out.println(text);
		xuatLine();

	}

	private void xuatCellThuTu(int i) {
		String paddLeft = "%3s";
		String paddRight = "%-6s";
		String text = "||" + String.format(paddLeft, " ") + String.format(paddRight, "" + i) + "|";
		System.out.print(text);
	}

	public void xuatTheoFormat(ArrayList<NhanVien> list) {
		xuatRowHeader();
		int i = 1;
		for (NhanVien nv : list) {
			xuatCellThuTu(i);
			nv.xuatRowFormat();
			i++;
		}
		xuatLine();
	}
}
