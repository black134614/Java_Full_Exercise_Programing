import java.util.ArrayList;
import java.util.Scanner;

/*
 * Mục đích: Tạo ra để quản lý danh sách nhiều nhân viên
 * Người tạo: Minh Luân
 * Ngày tạo: 27/12/2021
 * Version: 1.0
 * */
public class DanhSachNhanVien {
	// 1. Thuộc tính
	private ArrayList<NhanVien> listNV;
	// 2. Get, set methods
	/**
	 * @return the listNV
	 */
	public ArrayList<NhanVien> getListNV() {
		return listNV;
	}
	/**
	 * @param listNV the listNV to set 
	 */
	public void setListNV(ArrayList<NhanVien> listNV) {
		this.listNV = listNV;
	}
	// 3. Constructors methods
	public DanhSachNhanVien() {
		thietLapDefault();
	}
	// Hàm này dùng để khởi động các list và các giá trị mặc định cho lớp danh sách nhân viên
		private void thietLapDefault() {
			this.listNV = new ArrayList<NhanVien>();
		}
	// 4. Input, output methods
		//nhập danh sách nhân viên
		public void nhap(Scanner scan) {
			for (NhanVien nhanVien : listNV) {
				nhanVien.nhapNhanVien(scan);
			}
		}
		//thêm nhân viên vào list
		public void themNhanVien(NhanVien nhanVien) {
			this.listNV.add(nhanVien);
		}
		//xuất danh sách nhân viên
		public void xuat() {
			for (NhanVien nhanVien : listNV) {
				nhanVien.xuatThongTinNhanVien();
			}
		}
	// 5. Business methods
		//tính lương
		public void tinhLuong() {
			for (NhanVien nv : this.listNV) {
				nv.tinhLuong();
			}
		}
		//tìm người có lương cao nhất
		/*
		 * tìm mức lương cao nhất
		 * tìm các nhân viên sở hữu mức lương cao nhất
		 */
		public ArrayList<NhanVien> timNVCoLuongCaoNhat(){
			ArrayList<NhanVien> listNVLuongCaoNhat = new ArrayList<NhanVien>();
			if (this.listNV.size() > 0) {
				NhanVien nvMax = this.listNV.get(0); //
				int viTriMaxDauTien = 0;
				for (int i = 0; i < this.listNV.size(); i++) {
					NhanVien nvCurrent = this.listNV.get(i);
					if (nvCurrent.getLuong() > nvMax.getLuong()) {
						nvMax = nvCurrent;
						viTriMaxDauTien = i;
					}
				}
				listNVLuongCaoNhat.add(nvMax);
				for (int i = viTriMaxDauTien +1 ; i< this.listNV.size(); i++) {
					NhanVien nvCurrent = this.listNV.get(i);
					if (nvCurrent.getLuong() == nvMax.getLuong()) {
						listNVLuongCaoNhat.add(nvCurrent);
					}
				}
			}
			return listNVLuongCaoNhat;
		}
		
}
