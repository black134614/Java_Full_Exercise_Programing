import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

/*
 * Mục đích: Quản lý các nghiệp vụ liên quan đến Nhân viên
 * Người tạo: Minh Luân
 * Ngày tạo: 27/12/2021
 * Version: 1.0
 * */
public class NhanVien {
	// 1. Thuộc tính
	private int maNV;
	private String tenNV;
	private String ngaySinh;
	private String diaChi;
	private double luongCoBan;
	private float heSoLuong;
	private double luong;
	// 2. Get, set methods
	/**
	 * @return the maNV
	 */
	public int getMaNV() {
		return maNV;
	}
	/**
	 * @param maNV the maNV to set value
	 */
	public void setMaNV(int maNV) {
		this.maNV = maNV;
	}
	/**
	 * @return the tenNV
	 */
	public String getTenNV() {
		return tenNV;
	}
	/**
	 * @param tenNV the tenNV to set value
	 */
	public void setTenNV(String tenNV) {
		this.tenNV = tenNV;
	}
	/**
	 * @return the ngaySinh
	 */
	public String getNgaySinh() {
		return ngaySinh;
	}
	/**
	 * @param ngaySinh the ngaySinh to set value
	 */
	public void setNgaySinh(String ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	/**
	 * @return the diaChi
	 */
	public String getDiaChi() {
		return diaChi;
	}
	/**
	 * @param diaChi the diaChi to set value
	 */
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	/**
	 * @return the luongCoBan
	 */
	public double getLuongCoBan() {
		return luongCoBan;
	}
	/**
	 * @param luongCoBan the luongCoBan to set value
	 */
	public void setLuongCoBan(Double luongCoBan) {
		this.luongCoBan = luongCoBan;
	}
	/**
	 * @return the heSoLuong
	 */
	public float getHeSoLuong() {
		return heSoLuong;
	}
	/**
	 * @param heSoLuong the heSoLuong to set value
	 */
	public void setHeSoLuong(float heSoLuong) {
		this.heSoLuong = heSoLuong;
	}
	/**
	 * @return the luong
	 */
	public double getLuong() {
		return luong;
	}
	
	// 3. Constructors methods
	/**
	 * @param maNV
	 * @param tenNV
	 * @param ngaySinh
	 * @param diaChi
	 * @param heSoLuong
	 * @param luongCoBan
	 */
	public NhanVien( int maNV,String tenNV, String ngaySinh, String diaChi, float heSoLuong, double luongCoBan) {
		this.maNV = maNV;
		this.tenNV = tenNV;
		this.ngaySinh = ngaySinh;
		this.diaChi = diaChi;
		this.heSoLuong = heSoLuong;
		this.luongCoBan = luongCoBan;
	}
	//add for create new object in XyLy.Java
	public NhanVien() {
		// TODO Auto-generated constructor stub
	}
	
	// 4. Input, output methods
	public void nhapNhanVien(Scanner scan) {
		System.out.println("Nhập mã nhân viên");;
		this.maNV = Integer.parseInt(scan.nextLine());
		System.out.println("Họ và tên nhân viên:");
		this.tenNV = scan.nextLine();
		System.out.println("Ngày sinh (dd/MM/yyyy):");
		this.ngaySinh = scan.nextLine();
		System.out.println("Địa chỉ:");
		this.diaChi = scan.nextLine();
		System.out.println("Hệ số lương của nhân viên:");
		this.heSoLuong = Float.parseFloat(scan.nextLine());
		System.out.println("Lương cơ bản của nhân viên:");
		this.luongCoBan = Double.parseDouble(scan.nextLine());
	}
	
	public void xuatThongTinNhanVien() {
		System.out.println(" Mã nhân viên: " + this.maNV +"\t Tên nhân viên: " + this.getTenNV() + "\t Ngày sinh (dd/MM/yyyy): " + this.ngaySinh + 
				"\t Địa chỉ: " + this.diaChi + "\t Hệ số lương: " + this.heSoLuong + "\t Lương cơ bản: " + this.luongCoBan + "\t Lương thực tế: " + this.luong);
	}
	// 5. Business methods
	//tính lương
	public void tinhLuong() {
		this.luong = this.heSoLuong * this.luongCoBan;
	}
	//Hỗ trợ format xuất thông tin
	private String formatNumCell(Number num) {
		String paddLeft = "%5s";
		String paddRight = "%-8s";
		return String.format(paddLeft, " ") + String.format(paddRight, num) + "|";
	}

	private String formatTextCell(String text) {
		String paddLeft = "%-15s";
		return String.format(paddLeft, " " + text);
	}
	
	private String formatLongTextCell(String text) {
		String paddLeft = "%-40s";
		return String.format(paddLeft, " " + text);
	}

	public void xuatRowFormat() {
		String text;
		text = formatNumCell(this.maNV);
		text += formatTextCell(this.tenNV) + "|";
		text += formatTextCell(this.ngaySinh) + "|";
		text += formatLongTextCell(this.diaChi) + "|";
		text += formatNumCell(this.heSoLuong) ;
		//Hỗ trợ format number
//		NumberFormat formatter = new DecimalFormat("#0");
		//Hỗ trợ format tiền
		Locale locale = new Locale("vi", "VN");      
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);
		
		text += formatTextCell(currencyFormatter.format(this.luongCoBan)) + "|";
		text += formatTextCell(currencyFormatter.format(this.luong)) + "||";
		System.out.println(text);

	}
}
