import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/*
 * Mục đích: Quản lý các nghiệp vụ liên quan đến tài khoản ngân hàng: Nhập , xuất, nạp tiền, rút tiền, lãi đáo hạn, chuyển khoản
 * Bug: Chưa ràng buộc STK là duy nhất nên khi nạp rút, chuyển sẽ thực hiện tất cả thao tác trên các account có cùng STK.
 * Người tạo: Minh Luân
 * Ngày tạo: 03/01/2021
 * Version: 1.0
 * */
public class Account {
	// 1. Attributes
	// 2. get, set methods
	// 3. contructors
	// 4. input, output
	// 5. business methods

	// 1. Atttributes
	private int soTaiKhoan;
	private String tenTaiKhoan;
	//ngayGuiTien là tham số để tính đáo hạn cho tài khoản, mỗi lần đáo hạn sẽ reset lại ngayGuiTien
	private String ngayGuiTien;
	private double soTien;
	private int soNgayDaoHan;
	// Khởi tạo thuộc tính hằng số
	private static float Lai_Suat = 0.035f;
	private static int Phi_Rut_Tien = 3000;

	// 2. get, set methods
	/**
	 * @return the soTaiKhoan
	 */
	public int getSoTaiKhoan() {
		return soTaiKhoan;
	}

	/**
	 * @param soTaiKhoan the soTaiKhoan to set
	 */
	public void setSoTaiKhoan(int soTaiKhoan) {
		this.soTaiKhoan = soTaiKhoan;
	}

	/**
	 * 
	 * @return the tenTaiKhoan
	 */
	public String getTenTaiKhoan() {
		return tenTaiKhoan;
	}

	/**
	 * @param soTaiKhoan the soTaiKhoan to set
	 */
	public void setTenTaiKhoan(String tenTaiKhoan) {
		this.tenTaiKhoan = tenTaiKhoan;
	}

	/**
	 * @return the ngayGuiTien
	 */
	public String getNgayGuiTien() {
		return ngayGuiTien;
	}

	/**
	 * @param ngayGuiTien the ngayGuiTien to set
	 */
	public void setNgayGuiTien(String ngayGuiTien) {
		this.ngayGuiTien = ngayGuiTien;
	}

	/**
	 * @return the soTien
	 */
	public double getSoTien() {
		return soTien;
	}

	/**
	 * @return the laiSuat
	 */
	// Vì lãi suất sẽ so ngân hàng quyết định nên sẽ không set
	public float getLaiSuat() {
		return Lai_Suat;
	}

	/**
	 * @return the soNgayDaoHan
	 */
	public int getSoNgayDaoHan() {
		return soNgayDaoHan;
	}

	/**
	 * @param soNgayDaoHan the soNgayDaoHan to set
	 */
	public void setSoThangDAoHan(int soNgayDaoHan) {
		this.soNgayDaoHan = soNgayDaoHan;
	}

	// 3. contructors
	// khởi tạo để gọi ngoài xử lý
	public Account() {
	}

	/**
	 * @param soTaiKhoan
	 * @param tenTaiKhoan
	 * @param ngayGuiTien
	 * @param soTien
	 * @param laiSuat
	 * @param soNgayDaoHan
	 */
	public Account(int soTaiKhoan, String tenTaiKhoan, String ngayGuiTien, double soTien, int soNgayDaoHan) {
		this.soTaiKhoan = soTaiKhoan;
		this.tenTaiKhoan = tenTaiKhoan;
		this.soTien = soTien;
		this.ngayGuiTien = ngayGuiTien;
		this.soNgayDaoHan = soNgayDaoHan;
	}

	// 4. input / output

	public void nhap(Scanner scan) {
		System.out.println("Nhập số tài khoản: ");
		this.soTaiKhoan = Integer.parseInt(scan.nextLine());

		System.out.println("Nhập tên tài khoản: ");
		this.tenTaiKhoan = scan.nextLine();

		System.out.println("Nhập số tiền gửi: ");
		this.soTien = Double.parseDouble(scan.nextLine());

		// Kiểm tra date nhập
		boolean flag = false;
		System.out.println("Nhập ngày gửi tiền (dd/MM/yyyy): ");
		String stringDateInput = "";
		do {
			stringDateInput = scan.nextLine();
			if (isValidDate(stringDateInput) == false) {
				flag = true;
				System.out.println("Nhập sai định dạng ngày. Nhập lại.");
			} else {
				flag = false;
			}
		} while (flag);
		this.ngayGuiTien = stringDateInput;

		System.out.println("Nhập số ngày đáo hạn: ");
		this.soNgayDaoHan = Byte.parseByte(scan.nextLine());
	}
//Test xuất cho 1 account
//	public void xuat() {
//		System.out.println("Tài khoản - số tài khoản: " + this.soTaiKhoan + "\t Tên tài khoản: " + this.tenTaiKhoan
//				+ "\t Ngày gửi tiền: " + this.ngayGuiTien + "\t Số tiền trong tài khoản: " + this.soTien
//				+ "\t Số ngày đáo hạn: " + this.soNgayDaoHan);
//	}

	// 5. Business methods
	public void napTien(double soTienNap) {
		 this.soTien += soTienNap;
	}

	public void rutTien(double soTienRut) {
		if ((soTienRut + Phi_Rut_Tien) > this.soTien) {
			System.out.println("Bạn không đủ tiền để thực hiện.");
		} else {
			this.soTien -= (soTienRut + Phi_Rut_Tien);
		}
	}

	// Phương phức này chưa hoàn thiện. Vì chưa xác định được số tiền gửi đủ thời
	// gian để tính lãi đáo hạn.
	// Công thức yêu cầu đơn giản là số tiền trong tài khoản + số tiền trong tài
	// khoản * lãi suất ( sau 1 thời gian nhất định).
	public void daoHan() throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date ngayHienTai = new Date();
		Date ngayBatDau = dateFormat.parse(this.ngayGuiTien);

		// Trừ 2 ngày
		long diff = ngayHienTai.getTime() - ngayBatDau.getTime();

		// Quy đổi sang ngày
		TimeUnit time = TimeUnit.DAYS;
		long diffrenceDay = time.convert(diff, TimeUnit.MILLISECONDS);

		/*
		 * Nếu diffrenceDay >= 0 ==> TH1: đã tới hạn thì sẽ thực thi tính thêm lãi * số
		 * tiền hiện tại trong tài khoản. TH1 : sẽ có thêm trường hợp đã qua n lần đáo
		 * hạn ==> lặp lại n lần thực thi. TH1: cuối cùng sẽ lưu ngày gửi tiền là ngày
		 * đáo hạn cuối cùng. TH2: là chưa tới đáo hạn.
		 */
		if (diffrenceDay >= this.soNgayDaoHan) {
			do {
				diffrenceDay -= this.soNgayDaoHan;
				// chuyển date => localdate để cộng thêm ngày
				LocalDate toLocalDate = ngayBatDau.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				toLocalDate = toLocalDate.plusDays(this.soNgayDaoHan);
				// cập nhật lại ngày gửi tiền
				ngayBatDau = Date.from(toLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
				setNgayGuiTien(toLocalDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
				// cật nhật số tiền trong tài khoản
				this.soTien += this.soTien * Lai_Suat;
			} while (diffrenceDay >= this.soNgayDaoHan);

		} else {
			System.out.println("Tài khoản chưa đến kì đáo hạn.");
		}
	}
	// 6. Support Function

	// xác định ngày đúng định dạng
	public boolean isValidDate(String dateStr) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		dateFormat.setLenient(false);
		try {
			dateFormat.parse(dateStr);
		} catch (ParseException e) {
			return false;
		}
		return true;
	}

	public void xuat() {
		xuatRowHeader();
		xuatCellThuTu(1);
		xuatRowFormat();

		xuatLine();
	}

	// Hỗ trợ format xuất thông tin cell
	private String formatNumCell(Number num) {
		String paddLeft = "%6s";
		String paddRight = "%-7s";
		return String.format(paddLeft, " ") + String.format(paddRight, num) + "|";
	}
	
	private String formatLongNumCell(Number num) {
		String paddLeft = "%10s";
		String paddRight = "%-10s";
		return String.format(paddLeft, " ") + String.format(paddRight, num) + "|";
	}

	private String formatTextCell(String text) {
		String paddLeft = "%-15s";
		return String.format(paddLeft, " " + text) + "|";
	}

	private String formatLongTextCell(String text) {
		String paddLeft = "%-21s";
		return String.format(paddLeft, " " + text) + "|";
	}

	public void xuatRowFormat() {
		String text;
		text = formatNumCell(this.soTaiKhoan);
		text += formatLongTextCell(this.tenTaiKhoan);

		Locale locale = new Locale("vi", "VN");
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);

		text += formatTextCell(currencyFormatter.format(this.soTien));
		text += formatLongTextCell(this.ngayGuiTien);
		text += formatLongNumCell(this.soNgayDaoHan);
		System.out.println(text);

	}

	// Hỗ trợ xuất thông tin biểu mẫu
	private void xuatLine() {
		System.out.println("===========================================================================================================");
	}

	private String formatCell(String paddLeft, String title, String paddRight) {
		return String.format(paddLeft, " ") + title + String.format(paddRight, " ");
	}

	private void xuatRowHeader() {
		String paddString1 = "%3s";
		String paddString2 = "%4s";
		String paddString3 = "%5s";

		xuatLine();
		String text;
		text = "||" + formatCell(paddString1, "STT", paddString1) + "|";
		text += formatCell(paddString3, "STK", paddString3) + "|";
		text += formatCell(paddString2, "Tên tài khoản", paddString2) + "|";
		text += formatCell(paddString2, "Số tiền", paddString2) + "|";
		text += formatCell(paddString2, "Ngày đáo hạn", paddString2) + "|";
		text += formatCell(paddString2, "Số ngày D.Hạn", paddString2) + "|";
		System.out.println(text);
		xuatLine();

	}

	private void xuatCellThuTu(int i) {
		String paddLeft = "%3s";
		String paddRight = "%-6s";
		String text = "||" + String.format(paddLeft, " ") + String.format(paddRight, "" + i) + "|";
		System.out.print(text);
	}
}
