import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class XuLy {

	public static void main(String[] args) throws ParseException {
		Scanner scan = new Scanner(System.in);
		Bank bank = new Bank();
		bank.nhap();
		doMenu(bank);

	}

	private static void inMenu() {
		System.out.println("///////////////////////////////////////////////////////");
		System.out.println("Vui lòng chọn thực hiện:");
		System.out.println("1. Thêm tài khoản");
		System.out.println("2. Xuất thông tin tài khoản");
		System.out.println("3. Tính tiền đáo hạn cho tài khoản");
		System.out.println("4. Nạp tiền cho tài khoản");
		System.out.println("5. Rút tiền cho tài khoản");
		System.out.println("6. Chuyển khoản");
		System.out.println("7. Xuất thông tin tất cả tài khoản");
		System.out.println("0. Thoát");
	}

	private static void doMenu(Bank bank) throws ParseException {
		boolean flag = true;
		Scanner scan = new Scanner(System.in);
		int soTaiKhoan;
		// format tiền tệ vnd
		Locale locale = new Locale("vi", "VN");
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);
		do {
			inMenu();
			System.out.print("Mời chọn:");
			int chon = Integer.parseInt(scan.nextLine());
			switch (chon) {
			case 1:
				Account tk = new Account();
				tk.nhap(scan);
				bank.themTaiKhoan(tk);
				break;
			case 2:
				System.out.println("Nhập số tài khoản cần thao tác: ");
				soTaiKhoan = Integer.parseInt(scan.nextLine());
				Account tkTimDuoc = bank.timAccountTheoSTK(soTaiKhoan);
				if (tkTimDuoc != null) {
					tkTimDuoc.xuat();
				} else {
					System.out.println("Không có tài khoản: " + soTaiKhoan);
				}
				break;
			case 3:
				System.out.println("Nhập số tài khoản cần thao tác: ");
				soTaiKhoan = Integer.parseInt(scan.nextLine());
				tkTimDuoc = bank.timAccountTheoSTK(soTaiKhoan);
				if (tkTimDuoc != null) {
					tkTimDuoc.daoHan();
					System.out.println("Tài khoản " + tkTimDuoc.getSoTaiKhoan() + " có số dư "
							+ currencyFormatter.format(tkTimDuoc.getSoTien()));
				} else {
					System.out.println("Không có tài khoản: " + soTaiKhoan);
				}
				break;
			case 4:
				System.out.println("Nhập số tài khoản cần thao tác: ");
				soTaiKhoan = Integer.parseInt(scan.nextLine());
				tkTimDuoc = bank.timAccountTheoSTK(soTaiKhoan);
				if (tkTimDuoc != null) {
					System.out.println("Nhập số tiền cần nạp: ");
					double soTienNap = Integer.parseInt(scan.nextLine());
					tkTimDuoc.napTien(soTienNap);
					System.out.println("Tài khoản " + tkTimDuoc.getSoTaiKhoan() + " có số dư "
							+ currencyFormatter.format(tkTimDuoc.getSoTien()));
				} else {
					System.out.println("Không có tài khoản: " + soTaiKhoan);
				}
				break;
			case 5:
				System.out.println("Nhập số tài khoản cần thao tác: ");
				soTaiKhoan = Integer.parseInt(scan.nextLine());
				tkTimDuoc = bank.timAccountTheoSTK(soTaiKhoan);
				if (tkTimDuoc != null) {
					System.out.println("Nhập số tiền cần rút: ");
					double soTienRut = Integer.parseInt(scan.nextLine());
					tkTimDuoc.rutTien(soTienRut);
					System.out.println("Tài khoản " + tkTimDuoc.getSoTaiKhoan() + " có số dư "
							+ currencyFormatter.format(tkTimDuoc.getSoTien()));
				} else {
					System.out.println("Không có tài khoản: " + soTaiKhoan);
				}
				break;
			case 6:
				System.out.println("Nhập số tài khoản cần thao tác: ");
				soTaiKhoan = Integer.parseInt(scan.nextLine());
				tkTimDuoc = bank.timAccountTheoSTK(soTaiKhoan);
				if (tkTimDuoc != null) {
					System.out.println("Nhập số tài khoản cần chuyển tiền: ");
					int soTaiKhoanNhan = Integer.parseInt(scan.nextLine());
					if (bank.xacDinhTK(soTaiKhoanNhan)) {
						System.out.println("Phí chuyển tiền là 3.000đ");
						System.out.println("Nhập số tiền cần chuyển: ");
						Double soTienChuyen = Double.parseDouble(scan.nextLine());
						Account tkNhan = bank.timAccountTheoSTK(soTaiKhoanNhan);
						bank.chuyenKhoan(tkTimDuoc, tkNhan, soTienChuyen);
					} else {
						System.out.println("Không có tài khoản này: " + soTaiKhoan);
					}
				} else {
					System.out.println("Không có tài khoản: " + soTaiKhoan);
				}
				break;
			case 7:
				bank.xuatTatCaTheoFormat(bank.getListAccountOfBank().getListAccount());
				break;
			case 0:
				flag = false;
				break;
			}
		} while (flag);
	}
}
