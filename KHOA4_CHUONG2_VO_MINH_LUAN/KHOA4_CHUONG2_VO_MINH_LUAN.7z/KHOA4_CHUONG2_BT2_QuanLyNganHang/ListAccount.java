import java.util.ArrayList;
import java.util.Scanner;

/*
 * Mục đích: Tạo ra để quản lý danh sách nhiều tài khoản
 * Người tạo: Minh Luân
 * Ngày tạo: 03/01/2022
 * Version: 1.0
 * */
public class ListAccount {
	// 1. Attributes
	private ArrayList<Account> listAccount = new ArrayList<Account>();

	// 2. Get, set methods
	/**
	 * @return the listAccount
	 */
	public ArrayList<Account> getListAccount() {
		return listAccount;
	}

	/**
	 * @param listAccount the listAccount to set
	 */
	public void setListAcount(ArrayList<Account> listAccount) {
		this.listAccount = listAccount;
	}

	// 3. Constructors method
	public void DanhSachTK() {
		this.listAccount = new ArrayList<Account>();
	}

	// 4. Input, output methods
	public void nhap(Scanner scan) {
		for (Account account : this.listAccount) {
			account.nhap(scan);
		}
	}

	public void themTk(Account account) {
		this.listAccount.add(account);
	}
//Test xuất listAccount
//	public void xuatTatCaTK() {
//		for (Account account : this.listAccount) {
//			account.xuat();
//		}
//	}

	// 5. Business methods
	public Account timAccountTheoSTK(int soTaiKhoan) {
		Account tk = null;
		for (Account tk1 : this.listAccount) {
			if (tk1.getSoTaiKhoan() == soTaiKhoan) {
				tk = tk1;
				break;
			}
		}
		return tk;
	}

}
