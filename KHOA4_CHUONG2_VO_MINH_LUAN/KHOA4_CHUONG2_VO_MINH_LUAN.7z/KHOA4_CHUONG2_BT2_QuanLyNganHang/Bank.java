import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

/*
 * Mục đích: Quản lý toàn bộ nghiệp vụ cho ngân hàng ABC
 * Người tạo: Minh Luân
 * Ngày tạo: 03/01/2022
 * Version: 1.0
 * */
public class Bank {
	// 1. Attributes, Fields
	private ListAccount listAccountOfBank;
	// format tiền tệ vnd
	Locale locale = new Locale("vi", "VN");
	NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);

	// 2. get, set methods
	/**
	 * @return the listAccountOfBank
	 */
	public ListAccount getListAccountOfBank() {
		return listAccountOfBank;
	}

	/**
	 * @param listAccountOfBank the listAccountOfBank to set
	 */
	public void setListAccountOfBank(ListAccount listAccount) {
		this.listAccountOfBank = listAccount;
	}

	// 3. Constructors
	public Bank() {
		this.listAccountOfBank = new ListAccount();
	}

	// 4.input, ouput
	public void nhap() {
		Account tk = new Account(1, "VO MINH LUAN", "02/01/2022", 50, 365);
		this.listAccountOfBank.themTk(tk);

		tk = new Account(2, "NGUYEN HAI MY", "01/01/2021", 50, 365);
		this.listAccountOfBank.themTk(tk);
	}

	// 5. business methods
	public void themTaiKhoan(Account account) {
		this.listAccountOfBank.themTk(account);
	}

	public Account timAccountTheoSTK(int soTaiKhoan) {
		return listAccountOfBank.timAccountTheoSTK(soTaiKhoan);
	}

	public void rutTien( Account tk, double soTienRut) {
			tk.rutTien(soTienRut);
	}
	
	public void napTien(Account tk, double soTienNap) {
			tk.napTien(soTienNap);
	}
	
	public void chuyenKhoan(Account tkChuyen, Account tkNhan, double soTienChuyen) {
		tkChuyen.rutTien(soTienChuyen);
		tkNhan.napTien(soTienChuyen);
	}
	
	
	public boolean xacDinhTK(int soTaiKhoan) {
		if (listAccountOfBank.timAccountTheoSTK(soTaiKhoan) == null) {
			return false;
		}
		return true;
	}

	// Hỗ trợ xuất thông tin
	private void xuatLine() {
		System.out.println(
				"===========================================================================================================");
	}

	private String formatCell(String paddLeft, String title, String paddRight) {
		return String.format(paddLeft, " ") + title + String.format(paddRight, " ");
	}

	private void xuatRowHeader() {
		String paddString1 = "%3s";
		String paddString2 = "%4s";
		String paddString3 = "%5s";

		xuatLine();
		String text;
		text = "||" + formatCell(paddString1, "STT", paddString1) + "|";
		text += formatCell(paddString3, "STK", paddString3) + "|";
		text += formatCell(paddString2, "Tên tài khoản", paddString2) + "|";
		text += formatCell(paddString2, "Số tiền", paddString2) + "|";
		text += formatCell(paddString2, "Ngày đáo hạn", paddString2) + "|";
		text += formatCell(paddString2, "Số ngày D.Hạn", paddString2) + "|";
		System.out.println(text);
		xuatLine();

	}

	private void xuatCellThuTu(int i) {
		String paddLeft = "%3s";
		String paddRight = "%-6s";
		String text = "||" + String.format(paddLeft, " ") + String.format(paddRight, "" + i) + "|";
		System.out.print(text);
	}

	public void xuatTatCaTheoFormat(ArrayList<Account> list) {
		xuatRowHeader();
		int i = 1;
		for (Account tk : list) {
			xuatCellThuTu(i);
			tk.xuatRowFormat();
			i++;
		}
		xuatLine();
	}
}
